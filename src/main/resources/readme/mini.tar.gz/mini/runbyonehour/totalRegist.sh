###添加昨天12点的累计注册人数
#!/bin/bash

#定义连接参数
source /home/yoooum/mini/conf/db.cnf
hostName=$hostName
port=$port
userName=$userName
password=$passWord
dbName=$dbName

#获取参数
yesterday=$(date -d"1 day ago" +%Y%m%d)
echo "昨天:" $yesterday
#获取昨天12:00:00的时间戳
yesterday_sign=`date -d "$(date -d'1 day ago' +'%Y-%m-%d 12:00:00')" +%s`
echo "昨天12点时间戳:" $yesterday_sign

#1.获取昨天累计注册的人数--各个渠道
selectSql="select platformId,count(*) from PlayerRegister_$yesterday  group by platformId;"
registSumByBeforeTwoDay=`/usr/local/mysql-5.6.26/bin/mysql -h${hostName}  -P${port}  -u${userName} -p${password} ${dbName} -s -e  "$selectSql"`

#字符串转为数组
resultArray=(${registSumByBeforeTwoDay// / })
length=$((${#resultArray[*]}/2))
echo "渠道个数："$length

#2.入库
for ((i=0; i<$length; i++))
do 
    echo "insert into registerTotal values($yesterday_sign,${resultArray[2*$i]},${resultArray[2*$i+1]})"	
    /usr/local/mysql-5.6.26/bin/mysql -h${hostName}  -P${port}  -u${userName} -p${password} ${dbName} -s -e "insert into registerTotal values(null,$yesterday_sign,${resultArray[2*$i]},${resultArray[2*$i+1]})"
	
done

