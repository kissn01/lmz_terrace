#!/usr/bin/python
# -*- coding:utf-8 -*-
import xml.sax
#定义变量类 ListsData
class  LinesData:
   name = "" 
   type = ""
   size = ""
   desc = ""
   tabname = ""

#实行添加
class XmlStruct:
   def __init__(self):       
      self.lines = []
   def append(self,LinesData):
      self.lines.append(LinesData)
   def printlines(self):
      for i in range(len(self.lines)):
         #print ("序号：%s   值：%s" % (self.lines.index(i) + 1, i))
         print ("%s:%s:%s" % (self.lines[i].name,self.lines[i].type,self.lines[i].size))
          
               
class XmlHandler( xml.sax.ContentHandler ):
   def __init__(self):
      self.CurrentData = ""
      self.tablename = ""
      self.xmlstruct = {} 

   # 元素开始事件处理
   def startElement(self, tag, attributes):
      if tag == "entry":
         #print "*****Hello*****"
         line = LinesData()
         line.name = attributes["name"]               
         line.type = attributes["type"]
	 if attributes.has_key('size')==True:        
        	 line.size = attributes["size"]       
         line.desc = attributes["desc"] 

         #print self.tablename

         xml = self.xmlstruct[self.tablename]
         xml.append(line)

      elif tag == "struct":
         self.tablename = attributes["name"]
         xml = XmlStruct()
         self.xmlstruct[self.tablename] = xml

   def printall(self):       
       for k,v in self.xmlstruct.items():
         print k
         v.printlines()
         print "---------------------------"
   def getXmlStruct(self):
      return   self.xmlstruct    
   # 元素结束事件处理
   #def endElement(self, tag):
        #print "--------------END!---------------"
      

   # 内容事件处理
   #def characters(self, content):
       #print "--------------Hi!---------------"
  
if ( __name__ == "__main__"):
   
   # 创建一个 XMLReader
   parser = xml.sax.make_parser()
   # turn off namepsaces
   parser.setFeature(xml.sax.handler.feature_namespaces, 0)

   # 重写 ContextHandler
   Handler = XmlHandler()
   parser.setContentHandler( Handler )  
   parser.parse("ymcx-tlog.xml")
   #print ("我是外部调用---")
   Handler.printall()
   lists = {}
   lists = Handler.getXmlStruct()
   print len(lists)
   print lists.get('PlayerLoginOut')
   #print ("我是外部调用---")

