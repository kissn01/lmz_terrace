#!/usr/bin/env python
# -*- coding: utf-8 -*-
import pymysql
import xml.sax
import sys
import time
import re
import os
import string
import datetime
# 引用xml解析的格式
from ymcxtlog import XmlHandler

# 数据库连接参数
usedb = 'use db_mini_log'
config = {
    'host': '124.71.21.58',
    'port': 3306,
    'user': 'root',
    'passwd': 'root@appinside',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor,
}

# 类型判断
def to_int(str):
    try:
        int(str)
        return int(str)
    except ValueError:  # 报类型错误，说明不是整型的
        try:
            float(str)  # 用这个来验证，是不是浮点字符串
            return int(float(str))
        except ValueError:  # 如果报错，说明即不是浮点，也不是int字符串。   是一个真正的字符串
            return False

# 创建文件夹
def mkdir(path):
    # 去除首位空格
    path = path.strip()
    # 去除尾部 \ 符号
    path = path.rstrip("\\")

    # 判断路径是否存在
    # 存在     True
    # 不存在   False
    isExists = os.path.exists(path)

    # 判断结果
    if not isExists:
        # 如果不存在则创建目录
        # 创建目录操作函数
        os.makedirs(path)
        print path + ' 创建成功'
        return True
    else:
        # 如果目录存在则不创建，并提示目录已存在
        return False

# 获取类型
def getTypeDefault(form):
    defaultValue = ""
    if form == "int" or form == "uint":
        defaultValue = "0"
    elif form == "string":
        defaultValue = ""
    elif form == "datetime":
        defaultValue = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
    return defaultValue

# 添加默认值
def PackageValue(line, linesdict):
    # 判断line中 字段是否包含'或" 替换为
    s = "'"
    ss = '"'
    for i in range(len(line)):
        if s in line[i]:
            line[i] = line[i].replace("'", "彳")
        elif ss in line[i]:
            line[i] = line[i].replace('"', '亍')

    num = len(linesdict)
    linesNum = len(line)
    value = ""
    for i in range(num + 1):
        if i > 0:
            if i < linesNum:
                if i != 1:
                    value += ","
                value += "'"
                value += line[i]
                value += "'"
            else:
                value += ",'"
                value += getTypeDefault(linesdict[i - 1].type)
                value += "'"
    return value

class UploadLog():
    def __init__(self):
        self.conn = ""
        self.cursor = ""

    # 获取Mysql连接
    def ConnectDb(self, config):
        self.conn = pymysql.connect(**config)
        self.conn.autocommit(0)
        self.cursor = self.conn.cursor()
        self.cursor.execute(usedb)

    # 读取日志文件
    def readLog(self, fileName, dicts):
        if os.path.exists(fileName) == False:
            print "读取文件:%s 不存在,请检查！" % (fileName)
        else:
            fo = open(fileName, "r")
            lines = []
            lineNum = 1
            if lineNumber > 0:
                lineNumArgv = lineNumber
            else:
                lineNumArgv = 0
            for line in fo.readlines()[lineNumArgv:]:
                line = line.strip()
                lines = line.split("|")
                lineNum += 1
                tableName = lines[0]
                print(tableName);
                if dicts.has_key(tableName) != True:
                    continue
                sValue = PackageValue(lines, dicts[tableName].lines)
                # 构造和表名
                #tableName = lines[0] + "_" + datetime.datetime.strftime(
                #    datetime.datetime.now() - datetime.timedelta(hours=1), '%Y%m%d')
                tableName = lines[0] + "_"+"20201121" 
		sql = 'INSERT INTO  %s VALUES(0,%s)' % (tableName, sValue)
                print(sql)
                try:
                    self.cursor.execute(sql)
                    if lineNum % 10000 == 0:
                        self.conn.commit()
                        print datetime.datetime.now()
                except:
                    import traceback
                    print ("===%s===" % (sql))
                    traceback.print_exc()
                finally:
                    a = 1
            if lineNum % 10000 != 0:
                a = 1
                self.conn.commit()

# 判断接收的参数
argvLen = len(sys.argv)
if argvLen < 3:
    print "Hi,your args count %d < 3 :" % len(sys.argv)
    sys.exit(1)
elif argvLen == 3:
    xmlName = sys.argv[1]
    logName = sys.argv[2]
    lineNumber = 0
else:
    xmlName = sys.argv[1]
    logName = sys.argv[2]
    print "=============================="
    print sys.argv[3]
    if sys.argv[3].isdigit() == True:
        lineNumber = int(sys.argv[3])
    else:
        print ("行号: %s 输入错误,请请输入正确的行号!") % sys.argv[3]
        sys.exit(1)
# 解析xml获取数据格式
if (__name__ == "__main__"):
    # 开始执行时候打印时间
    dtEventTime = datetime.datetime.now()
    print dtEventTime

    nowPath = sys.path[0]
    writeLogPath = nowPath + '/log'
    # 创建文件夹
    # mkdir(writeLogPath)
    parser = xml.sax.make_parser()
    parser.setFeature(xml.sax.handler.feature_namespaces, 0)
    # 重写 ContextHandler
    Handler = XmlHandler()
    parser.setContentHandler(Handler)
    parser.parse(xmlName)
    dicts = {}
    dicts = Handler.getXmlStruct()
    uploadlog = UploadLog()
    uploadlog.ConnectDb(config)
    uploadlog.readLog(logName, dicts)
