#!/bin/bash
#1.根据xml 获取需要建造的 表名
echo "---建表begin---"
tbList=`awk '/<struct[ \t]+name=/{gsub(/^[^"]+"|".*/,"");print}'  /home/yoooum/mini/conf/tlog_cfg.xml`

#2.获取明天日期
date=$(date -d next-day "+%Y%m%d")
#当天
#date=$(date "+%Y%m%d")
echo $date
#3.定义连接参数
source /home/yoooum/mini/conf/db.cnf
hostName=$hostName
port=$port
userName=$userName
password=$passWord
dbName=$dbName

#4.循环读取表名 建表
for var in ${tbList[@]}
do
        #1.构造表名
        tbName=$var"_"$date
        #2.构造建表语句
        create_sql="create table IF NOT  EXISTS $tbName  like  $var"
        #3.建表
	echo $create_sql
	/usr/local/mysql-5.6.26/bin/mysql -h${hostName}  -P${port}  -u${userName} -p${password} ${dbName} -e  "$create_sql"
done
echo "---建表end---"

