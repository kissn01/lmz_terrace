###每天一点定时执行主程序
#!/bin/bash

#进入每天1点执行目录
cd /home/yoooum/mini/runbyonehour

#昨天注册人数入库
./totalRegist.sh

