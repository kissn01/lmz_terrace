#!/bin/bash
#手动插入某天某一张表 要求把当天所有该表数据写入一个文件
#cat ymcx_20201121_0*.log|grep "FinishTask" >finishtask.log

#$1 为读取的文件名
#执行时注意修改manual.py的日期 即表名 入到哪个库

#读取的文件全路径： 指定文件夹/ymcx_yearmmdd_hh_mm.log  /data/tlog/log/ymcx_20190729_1400.log
logFile='/data/tlog/log/'$1
#读取的xml
readXml='/home/yoooum/mini/conf/tlog_cfg.xml'
#执行的python文件
executePythonFile='/home/yoooum/mini/runbyevenyhour/manual.py'
#执行 logDb.py(按照xml格式读取文件)  参数: 解析的xml格式  读取的文件
python  $executePythonFile  $readXml   $logFile

